"use strict";
(self["webpackChunkJupyterLabFS"] = self["webpackChunkJupyterLabFS"] || []).push([["lib_index_js"],{

/***/ "./lib/index.js":
/*!**********************!*\
  !*** ./lib/index.js ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/notebook */ "webpack/sharing/consume/default/@jupyterlab/notebook");
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _jupyterlab_cells__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @jupyterlab/cells */ "webpack/sharing/consume/default/@jupyterlab/cells");
/* harmony import */ var _jupyterlab_cells__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_cells__WEBPACK_IMPORTED_MODULE_2__);



/**
 * Initialization data for the jupyterlab_apod extension.
 */
const plugin = {
    id: 'FullScreen',
    description: 'Full Screen',
    autoStart: true,
    requires: [_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.ICommandPalette, _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_1__.INotebookTracker],
    activate: (app, palette, tracker) => {
        console.log('JupyterLab extension activated!');
        console.log('ICommandPalette:', palette);
        const toggleFullScreenCommand = 'notebook:toggle-output-fullscreen';
        app.commands.addCommand(toggleFullScreenCommand, {
            label: 'Toggle Full Screen Output',
            execute: () => {
                const current = tracker.currentWidget;
                if (!current) {
                    return;
                }
                const notebook = current.content;
                const activeCell = notebook.activeCell;
                if (!activeCell || !(activeCell instanceof _jupyterlab_cells__WEBPACK_IMPORTED_MODULE_2__.CodeCell)) {
                    return;
                }
                // Get the content inside the output area
                const outputContent = activeCell.outputArea.node.children[0]; //.querySelector('.jp-OutputArea-output');
                if (!outputContent) {
                    return;
                }
                const isFullscreen = document.fullscreenElement === outputContent;
                if (isFullscreen) {
                    document.exitFullscreen().then(() => {
                        outputContent.classList.remove('fullscreen');
                    }).catch((err) => console.log(err));
                }
                else {
                    outputContent.classList.add('fullscreen');
                    outputContent.requestFullscreen().catch((err) => console.log(err));
                }
            }
        });
        palette.addItem({ command: toggleFullScreenCommand, category: 'Notebook Operations' });
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (plugin);


/***/ })

}]);
//# sourceMappingURL=lib_index_js.799d7e5e84ace3e04675.js.map